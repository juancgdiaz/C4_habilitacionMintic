package com.usa.C4_habilitacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class C4_habilitacionApplicationTests {

    @Test
    void contextLoads() {
    }

}
